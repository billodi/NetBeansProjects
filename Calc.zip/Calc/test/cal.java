

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.plaf.multi.MultiLabelUI;
import javax.swing.plaf.multi.MultiListUI;
import javax.swing.text.html.HTML;

/**
 *
 * @author Buddika Alwis
 */
public class cal {

    static String all = ("0");
    static String allsum = ("0");
    static Boolean mul = false;
    static Boolean div = false;
    static Boolean plus = false;
    static Boolean sub = false;
    static Boolean subb = false;
    static Boolean divs = false;
    static Boolean muls = false;

    public static void main(String[] args) {
        JFrame calWin = new JFrame();

        JButton calNo_1 = new JButton();
        JButton calNo_2 = new JButton();
        JButton calNo_3 = new JButton();
        JButton calNo_4 = new JButton();
        JButton calNo_5 = new JButton();
        JButton calNo_6 = new JButton();
        JButton calNo_7 = new JButton();
        JButton calNo_8 = new JButton();
        JButton calNo_9 = new JButton();
        JButton calNo_0 = new JButton();
        JButton calNo_c = new JButton();
        JButton calNo_b = new JButton();
        JButton calNo_sub = new JButton();
        JButton calNo_plus = new JButton();
        JButton calNo_div = new JButton();
        JButton calNo_mul = new JButton();
        JButton calNo_sum = new JButton();

        JTextField input = new JTextField();

        JLabel output = new JLabel();

        output.setSize(230, 70);
        output.setLocation(10, 50);
        output.setText("Answer");

        input.setSize(230, 40);
        input.setLocation(10, 10);

        calNo_0.setSize(170, 50);
        calNo_0.setLocation(10, 400);
        calNo_0.setText("0");

        calNo_1.setSize(50, 50);
        calNo_1.setLocation(10, 340);
        calNo_1.setText("1");

        calNo_2.setSize(50, 50);
        calNo_2.setLocation(70, 340);
        calNo_2.setText("2");

        calNo_3.setSize(50, 50);
        calNo_3.setLocation(130, 340);
        calNo_3.setText("3");

        calNo_4.setSize(50, 50);
        calNo_4.setLocation(10, 280);
        calNo_4.setText("4");

        calNo_5.setSize(50, 50);
        calNo_5.setLocation(70, 280);
        calNo_5.setText("5");

        calNo_6.setSize(50, 50);
        calNo_6.setLocation(130, 280);
        calNo_6.setText("6");

        calNo_7.setSize(50, 50);
        calNo_7.setLocation(10, 220);
        calNo_7.setText("7");

        calNo_8.setSize(50, 50);
        calNo_8.setLocation(70, 220);
        calNo_8.setText("8");

        calNo_9.setSize(50, 50);
        calNo_9.setLocation(130, 220);
        calNo_9.setText("9");

        calNo_c.setSize(110, 50);
        calNo_c.setLocation(10, 160);
        calNo_c.setText("C");

        calNo_b.setSize(50, 50);
        calNo_b.setLocation(70, 160);
        calNo_b.setText("<");

        calNo_sub.setSize(50, 50);
        calNo_sub.setLocation(130, 160);
        calNo_sub.setText("-");

        calNo_plus.setSize(50, 50);
        calNo_plus.setLocation(190, 160);
        calNo_plus.setText("+");

        calNo_div.setSize(50, 50);
        calNo_div.setLocation(190, 220);
        calNo_div.setText("/");

        calNo_mul.setSize(50, 50);
        calNo_mul.setLocation(190, 280);
        calNo_mul.setText("X");

        calNo_sum.setSize(50, 110);
        calNo_sum.setLocation(190, 340);
        calNo_sum.setText("=");

        calWin.add(calNo_0);
        calWin.add(calNo_1);
        calWin.add(calNo_2);
        calWin.add(calNo_3);
        calWin.add(calNo_4);
        calWin.add(calNo_5);
        calWin.add(calNo_6);
        calWin.add(calNo_7);
        calWin.add(calNo_8);
        calWin.add(calNo_9);
        calWin.add(calNo_c);

        calWin.add(calNo_sub);
        calWin.add(calNo_plus);
        calWin.add(calNo_div);
        calWin.add(calNo_mul);
        calWin.add(calNo_sum);
        calWin.add(input);
        calWin.add(output);

        input.addKeyListener(new KeyListener() {

            public void keyTyped(KeyEvent ke) {
                String k = String.valueOf(ke.getKeyChar());
                if (input.getText().isEmpty() & k.equals("0") | !Character.isDigit(ke.getKeyChar())) {

                    ke.consume();
                }
                if (k.equals("\n")) {
                    if (plus == true) {
                        if (!input.getText().isEmpty()) {
                            output.setText(String.valueOf(Double.parseDouble(input.getText()) + Double.parseDouble(allsum)));
                        } else {
                            output.setText(allsum);
                        }
                    }
                    if (sub == true) {
                        if (!input.getText().isEmpty()) {
                            output.setText(String.valueOf(Double.parseDouble(input.getText()) - Double.parseDouble(allsum)));
                        } else {
                            output.setText(allsum);
                        }
                    }
                    if (mul == true) {
                        if (!input.getText().isEmpty()) {
                            output.setText(String.valueOf(Double.parseDouble(input.getText()) * Double.parseDouble(allsum)));
                        } else {
                            output.setText(allsum);
                        }
                    }
                    if (div == true) {
                        if (!input.getText().isEmpty()) {
                            output.setText(String.valueOf(Double.parseDouble(input.getText()) / Double.parseDouble(allsum)));
                        } else {
                            output.setText(allsum);
                        }
                    }
                    System.out.println(all);
                    plus = false;
                    sub = false;
                    divs = false;
                    muls = false;
                    input.setText("");
                }
                if (k.equals("+")) {
                    if (!input.getText().isEmpty() & mul == false & div == false) {
                        if (output.getText().equals("Answer")) {
                            output.setText("0");
                        }
                        String plus = plus(input.getText(), output.getText());
                        output.setText(plus);
                        allsum = plus;
                        if (!all.equals("")) {
                            all = (all + " + " + input.getText() + " = " + allsum);
                        } else {
                            all = (input.getText());
                        }

                        input.setText("");

                    } else if (mul == true) {
                        String mul = mul(input.getText(), output.getText());
                        output.setText(mul);
                        allsum = mul;

                        input.setText("");
                        if (!all.equals("")) {
                            all = (all + " * " + input.getText() + " = " + allsum);
                        } else {
                            all = (input.getText());
                        }
                    } else if (div == true) {
                        String div = div(input.getText(), output.getText());
                        output.setText(div);
                        allsum = div;
                        if (!all.equals("")) {
                            all = (all + " / " + input.getText() + " = " + allsum);
                        } else {
                            all = (input.getText());
                        }

                        input.setText("");
                    }
                    plus = true;
                    sub = false;
                    divs = false;
                    muls = false;
                    mul = false;
                    div = false;
                }
                if (k.equals("-")) {
                    if (!input.getText().isEmpty() & mul == false & div == false) {
                        if (output.getText().equals("Answer")) {
                            output.setText("0");
                        }
                        String sub = sub(input.getText(), output.getText());
                        output.setText(sub);
                        allsum = sub;
                        if (!all.equals("")) {
                            all = (all + " - " + input.getText() + " = " + allsum);
                        } else {
                            all = (input.getText());
                        }

                        input.setText("");

                    } else if (mul == true) {
                        String mul = mul(input.getText(), output.getText());
                        output.setText(mul);
                        allsum = mul;

                        input.setText("");
                        if (!all.equals("")) {
                            all = (all + " * " + input.getText() + " = " + allsum);
                        } else {
                            all = (input.getText());
                        }
                    } else if (div == true) {
                        String div = div(input.getText(), output.getText());
                        output.setText(div);
                        allsum = div;
                        if (!all.equals("")) {
                            all = (all + " / " + input.getText() + " = " + allsum);
                        } else {
                            all = (input.getText());
                        }

                        input.setText("");
                    }
                    plus = false;
                    sub = true;
                    divs = false;
                    muls = false;
                    mul = false;
                    div = false;
                }
                if (k.equals("*")) {
                    if (!input.getText().isEmpty()) {
                        if (!output.getText().equals("Answer")) {
                            String mul = mul(input.getText(), output.getText());
                            output.setText(mul);
                            allsum = mul;

                            input.setText("");
                            if (!all.equals("")) {
                                all = (all + " * " + input.getText() + " = " + allsum);
                            } else {
                                all = (input.getText());
                            }
                        } else {
                            output.setText(input.getText());
                            allsum = input.getText();
                            input.setText("");
                            mul = true;
                        }

                    }
                    plus = false;
                    sub = false;
                    divs = false;
                    muls = true;
                }
                if (k.equals("/")) {
                    if (!input.getText().isEmpty()) {
                        if (!output.getText().equals("Answer")) {
                            String div = div(input.getText(), output.getText());
                            output.setText(div);
                            allsum = div;
                            if (!all.equals("")) {
                                all = (all + " / " + input.getText() + " = " + allsum);
                            } else {
                                all = (input.getText());
                            }

                            input.setText("");

                        } else {
                            output.setText(input.getText());
                            allsum = input.getText();
                            input.setText("");
                            div = true;
                        }

                    }
                    plus = false;
                    sub = false;
                    divs = true;
                    muls = false;
                }
                if (k.equals("0")) {
                    
                    calNo_0.setBackground(Color.BLACK);
                    try {
                        
                        
                        wait(1000);
                        
                    } catch (Exception e) {
                    }
                    calNo_0.setBackground(Color.ORANGE);
                    try {
                        
                        wait(1000);
                        
                    } catch (Exception e) {
                    }
                    calNo_0.setBackground(Color.BLACK);
                    
                }
                if (k.equals("1")) {

                }
                if (k.equals("2")) {

                }
                if (k.equals("3")) {

                }
                if (k.equals("4")) {

                }
                if (k.equals("5")) {

                }
                if (k.equals("6")) {

                }
                if (k.equals("7")) {

                }
                if (k.equals("8")) {

                }
                if (k.equals("9")) {

                }

            }

            @Override
            public void keyPressed(KeyEvent ke) {

            }

            @Override
            public void keyReleased(KeyEvent ke) {
            }
        });

        calNo_0.addActionListener((ae) -> {
            if (!input.getText().equals("")) {
                input.setText(input.getText() + "0");
            } else {

            }
            input.requestFocus();
        });

        calNo_1.addActionListener((ae) -> {
            input.setText(input.getText() + "1");
            input.requestFocus();
        });

        calNo_2.addActionListener((ae) -> {
            input.setText(input.getText() + "2");
            input.requestFocus();
        });

        calNo_3.addActionListener((ae) -> {
            input.setText(input.getText() + "3");
            input.requestFocus();
        });

        calNo_4.addActionListener((ae) -> {
            input.setText(input.getText() + "4");
            input.requestFocus();
        });

        calNo_5.addActionListener((ae) -> {
            input.setText(input.getText() + "5");
            input.requestFocus();
        });

        calNo_6.addActionListener((ae) -> {
            input.setText(input.getText() + "6");
            input.requestFocus();
        });

        calNo_7.addActionListener((ae) -> {
            input.setText(input.getText() + "7");
            input.requestFocus();
        });

        calNo_8.addActionListener((ae) -> {
            input.setText(input.getText() + "8");
            input.requestFocus();
        });

        calNo_9.addActionListener((ae) -> {
            input.setText(input.getText() + "9");
            input.requestFocus();
        });

        calNo_c.addActionListener((ae) -> {
            input.setText("");
            allsum = ("");
            all = ("");
            output.setText("Answer");
            input.requestFocus();
        });

        calNo_plus.addActionListener((ae) -> {
            if (!input.getText().isEmpty() & mul == false & div == false) {
                if (output.getText().equals("Answer")) {
                    output.setText("0");
                }
                String plus = plus(input.getText(), output.getText());
                output.setText(plus);
                allsum = plus;
                if (!all.equals("")) {
                    all = (all + " + " + input.getText() + " = " + allsum);
                } else {
                    all = (input.getText());
                }

                input.setText("");

            } else if (mul == true) {
                String mul = mul(input.getText(), output.getText());
                output.setText(mul);
                allsum = mul;

                input.setText("");
                if (!all.equals("")) {
                    all = (all + " * " + input.getText() + " = " + allsum);
                } else {
                    all = (input.getText());
                }
            } else if (div == true) {
                String div = div(input.getText(), output.getText());
                output.setText(div);
                allsum = div;
                if (!all.equals("")) {
                    all = (all + " / " + input.getText() + " = " + allsum);
                } else {
                    all = (input.getText());
                }

                input.setText("");
            }
            plus = true;
            sub = false;
            divs = false;
            muls = false;
            mul = false;
            div = false;
            input.requestFocus();
        });

        calNo_sub.addActionListener((ae) -> {
            if (!input.getText().isEmpty() & mul == false & div == false) {
                if (output.getText().equals("Answer")) {
                    output.setText(input.getText());
                    allsum = input.getText();
                    input.setText("");
                    subb = true;
                } else {
                    String sub = sub(input.getText(), output.getText());
                    output.setText(sub);
                    allsum = sub;
                    if (!all.equals("")) {
                        all = (all + " - " + input.getText() + " = " + allsum);
                    } else {
                        all = (input.getText());
                    }

                    input.setText("");

                    if (mul == true) {
                        String mul = mul(input.getText(), output.getText());
                        output.setText(mul);
                        allsum = mul;

                        input.setText("");
                        if (!all.equals("")) {
                            all = (all + " * " + input.getText() + " = " + allsum);
                        } else {
                            all = (input.getText());
                        }
                    } else if (div == true) {
                        String div = div(input.getText(), output.getText());
                        output.setText(div);
                        allsum = div;
                        if (!all.equals("")) {
                            all = (all + " / " + input.getText() + " = " + allsum);
                        } else {
                            all = (input.getText());
                        }

                        input.setText("");
                    }

                }
                plus = false;
                sub = true;
                divs = false;
                muls = false;
                mul = false;
                div = false;
                input.requestFocus();
            }});

            calNo_div.addActionListener((ae) -> {
                if (!input.getText().isEmpty()& !subb == true) {
                    if (!output.getText().equals("Answer")) {
                        String div = div(input.getText(), output.getText());
                        output.setText(div);
                        allsum = div;
                        if (!all.equals("")) {
                            all = (all + " / " + input.getText() + " = " + allsum);
                        } else {
                            all = (input.getText());
                        }

                        input.setText("");

                    } else {
                        output.setText(input.getText());
                        allsum = input.getText();
                        input.setText("");
                        div = true;
                    }

                }else{
                    
                    String sub = sub(input.getText(), output.getText());
                    output.setText(sub);
                    allsum = sub;
                    if (!all.equals("")) {
                        all = (all + " - " + input.getText() + " = " + allsum);
                    } else {
                        all = (input.getText());
                    }

                    input.setText("");

                    if (mul == true) {
                        String mul = mul(input.getText(), output.getText());
                        output.setText(mul);
                        allsum = mul;

                        input.setText("");
                        if (!all.equals("")) {
                            all = (all + " * " + input.getText() + " = " + allsum);
                        } else {
                            all = (input.getText());
                        }
                    } else if (div == true) {
                        String div = div(input.getText(), output.getText());
                        output.setText(div);
                        allsum = div;
                        if (!all.equals("")) {
                            all = (all + " / " + input.getText() + " = " + allsum);
                        } else {
                            all = (input.getText());
                        }

                        input.setText("");
                    }

                
                }
                plus = false;
                sub = false;
                divs = true;
                muls = false;
                subb = false;
                input.requestFocus();
            });

            calNo_mul.addActionListener((ae) -> {
                if (!input.getText().isEmpty()&!subb == true) {
                    if (!output.getText().equals("Answer")) {
                        String mul = mul(input.getText(), output.getText());
                        output.setText(mul);
                        allsum = mul;

                        input.setText("");
                        if (!all.equals("")) {
                            all = (all + " * " + input.getText() + " = " + allsum);
                        } else {
                            all = (input.getText());
                        }
                    } else {
                        output.setText(input.getText());
                        allsum = input.getText();
                        input.setText("");
                        mul = true;
                    }

                }else {
                    
                    String sub = sub(input.getText(), output.getText());
                    output.setText(sub);
                    allsum = sub;
                    if (!all.equals("")) {
                        all = (all + " - " + input.getText() + " = " + allsum);
                    } else {
                        all = (input.getText());
                    }

                    input.setText("");

                    if (mul == true) {
                        String mul = mul(input.getText(), output.getText());
                        output.setText(mul);
                        allsum = mul;

                        input.setText("");
                        if (!all.equals("")) {
                            all = (all + " * " + input.getText() + " = " + allsum);
                        } else {
                            all = (input.getText());
                        }
                    } else if (div == true) {
                        String div = div(input.getText(), output.getText());
                        output.setText(div);
                        allsum = div;
                        if (!all.equals("")) {
                            all = (all + " / " + input.getText() + " = " + allsum);
                        } else {
                            all = (input.getText());
                        }

                        input.setText("");
                    }

                
                }
                plus = false;
                sub = false;
                divs = false;
                muls = true;
                subb = false;
                input.requestFocus();
            });

            calNo_sum.addActionListener((ae) -> {
                if (plus == true) {
                    if (!input.getText().isEmpty()) {
                        output.setText(String.valueOf(Double.parseDouble(input.getText()) + Double.parseDouble(allsum)));
                    } else {
                        output.setText(allsum);
                    }
                }
                if (sub == true) {
                    if (!input.getText().isEmpty()) {
                        output.setText(String.valueOf(Double.parseDouble(allsum)-Double.parseDouble(input.getText())));
                    } else {
                        output.setText(allsum);
                    }
                }
                if (muls == true) {
                    if (!input.getText().isEmpty()) {
                        output.setText(String.valueOf(Double.parseDouble(input.getText()) * Double.parseDouble(allsum)));
                    } else {
                        output.setText(allsum);
                    }
                }
                if (divs == true) {
                    if (!input.getText().isEmpty()) {
                        output.setText(String.valueOf(Double.parseDouble(input.getText()) / Double.parseDouble(allsum)));
                    } else {
                        output.setText(allsum);
                    }
                }
                System.out.println(all);
                plus = false;
                sub = false;
                divs = false;
                muls = false;
                input.setText("");
                input.requestFocus();
            });

            calWin.setSize(267, 500);
            calWin.setLayout(null);
            calWin.setVisible(true);
            calWin.setLocationRelativeTo(null);

            calWin.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

            input.requestFocus();
        }

    public static void plusbutton() {

    }

    public static String plus(String in1, String in2) {
        double i1 = Double.parseDouble(in1);
        double i2 = Double.parseDouble(in2);
        double t = i1 + i2;
        String out = String.valueOf(t);
        return out;
    }

    public static String sub(String in1, String in2) {
        double i1 = Double.parseDouble(in1);
        double i2 = Double.parseDouble(in2);
        double t = i2 - i1;
        String out = String.valueOf(t);
        return out;
    }

    public static String mul(String in1, String in2) {
        double i1 = Double.parseDouble(in1);
        double i2 = Double.parseDouble(in2);
        double t = i1 * i2;
        String out = String.valueOf(t);
        return out;
    }

    public static String div(String in1, String in2) {
        double i1 = Double.parseDouble(in1);
        double i2 = Double.parseDouble(in2);
        double t = i2 / i1;
        String out = String.valueOf(t);
        return out;
    }

}
